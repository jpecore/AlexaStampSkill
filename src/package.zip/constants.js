"use strict";

module.exports = Object.freeze({
    
    // App-ID. TODO: set to your own Skill App ID from the developer portal.
    appId : 'amzn1.ask.skill.5def441f-b36d-4f44-a8d7-f3c1a4837e17',
    
    //  DynamoDB Table name
    dynamoDBTableName : 'stampSkill'
    
    
});